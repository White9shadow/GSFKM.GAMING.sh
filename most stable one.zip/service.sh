#!/system/bin/sh
MODDIR=${0%/*}
SCRIPT_DIR="$MODDIR/script"

if [ "$(cat $SCRIPT_DIR/pathinfo.sh | grep "$PATH")" == "" ]; then
    echo "" >> $SCRIPT_DIR/pathinfo.sh
    echo "# prefer to use busybox provided by magisk" >> $SCRIPT_DIR/pathinfo.sh
    echo "PATH=$PATH" >> $SCRIPT_DIR/pathinfo.sh
fi

# not relying on executable permissions
rm -rf $MODPATH/gmsblock
rm -rf $MODPATH/tweaks
rm -rf $MODPATH/LICENSE
rm -rf $MODPATH/sys
rm -rf $MODPATH/system/etc/init.d
rm -rf $MODPATH/system/etc/init
rm -rf $MODPATH/system/bin
