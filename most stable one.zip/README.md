# GODSPEED STABLE UNIVERSAL
# VERSION = v2.0 | UNIVERSAL
# DATE = 16-8-2021
# thermals from razzer (rros rom)
# better RAM Management
# Fixed Scrolling issue
# more smoothness in game
# thermal engine for pubg hd graphic
# scrolling lag fixed
# fps booster from @wearerevens
#YT-https://youtube.com/c/WhiteShadowGameEra

